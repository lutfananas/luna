// Jalankan: node tests/run-tests.js
'use strict';
globalThis.LunaTA = require('../js/ta.js');
globalThis.LunaBacktest = require('../js/backtest.js');
globalThis.LunaPineExt = require('../js/pine-ext.js');
const Pine = require('../js/pine.js');
const { EXAMPLES } = require('../js/scripts.js');

let failed = 0;
function ok(cond, msg) {
  if (cond) console.log('  ok   ' + msg);
  else { console.log('  FAIL ' + msg); failed++; }
}
const near = (a, b, eps = 1e-6) => Math.abs(a - b) <= eps * Math.max(1, Math.abs(b));

// data simulasi deterministik
function makeBars(n, seed = 7) {
  let s = seed;
  const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
  const bars = [];
  let p = 100;
  for (let i = 0; i < n; i++) {
    const o = p;
    const c = o * (1 + (rnd() - 0.5) * 0.04);
    const h = Math.max(o, c) * (1 + rnd() * 0.01);
    const l = Math.min(o, c) * (1 - rnd() * 0.01);
    bars.push({ time: Date.UTC(2024, 0, 1) + i * 3600e3, open: +o.toFixed(2), high: +h.toFixed(2), low: +l.toFixed(2), close: +c.toFixed(2), volume: 100 + rnd() * 50 });
    p = c;
  }
  return bars;
}
const bars = makeBars(600);
const run = (src, inputs, tf = '1h') => Pine.run(Pine.compile(src), bars, { inputs, timeframe: tf });

console.log('Contoh bawaan');
for (const ex of EXAMPLES) {
  const r = run(ex.code);
  ok(!r.error, `${ex.name} jalan tanpa error ${r.error || ''}`);
  if (r.strategy) console.log(`       trades=${r.strategy.metrics.totalTrades} net=${r.strategy.metrics.netProfit.toFixed(2)} winrate=${r.strategy.metrics.winRate.toFixed(1)}%`);
}

console.log('Indikator vs perhitungan manual');
{
  const r = run(`indicator("t")\nplot(ta.sma(close, 5))\nplot(ta.ema(close, 5))\nplot(close[2])\nplot(ta.rsi(close, 14))`);
  const sma = r.plots[0].values, ema = r.plots[1].values, lag = r.plots[2].values;
  const i = 100;
  const manual = bars.slice(i - 4, i + 1).reduce((a, b) => a + b.close, 0) / 5;
  ok(near(sma[i], manual), 'ta.sma benar');
  ok(Number.isNaN(sma[3]) && !Number.isNaN(sma[4]), 'ta.sma NaN sebelum cukup data');
  let e = bars.slice(0, 5).reduce((a, b) => a + b.close, 0) / 5;
  for (let k = 5; k <= i; k++) e = (2 / 6) * bars[k].close + (1 - 2 / 6) * e;
  ok(near(ema[i], e), 'ta.ema benar (seed SMA)');
  ok(lag[i] === bars[i - 2].close && Number.isNaN(lag[1]), 'close[2] histori benar');
  const rsi = r.plots[3].values;
  ok(rsi[200] > 0 && rsi[200] < 100, 'ta.rsi dalam rentang 0..100');
}

console.log('var, :=, if/else, for, fungsi');
{
  const r = run(`indicator("t")
var count = 0
x = 0
if close > open
    count := count + 1
    x := 1
else if close < open
    x := -1
else
    x := 0
total = 0.0
for i = 1 to 3
    total += i
f(a, b = 2) => a * b
g(v) =>
    s = ta.sma(v, 3)
    s * 2
plot(count)
plot(x)
plot(total)
plot(f(3))
plot(g(close))
plot(f(a = 5, b = 3))`);
  ok(!r.error, 'kompilasi & jalan ' + (r.error || ''));
  const ups = bars.filter((b) => b.close > b.open).length;
  ok(r.plots[0].values[bars.length - 1] === ups, 'var count akumulasi benar');
  ok(r.plots[1].values[10] === Math.sign(bars[10].close - bars[10].open), 'if/else if/else benar');
  ok(r.plots[2].values[5] === 6, 'for loop benar');
  ok(r.plots[3].values[5] === 6, 'fungsi dengan default param');
  const i = 50;
  ok(near(r.plots[4].values[i], 2 * (bars[i].close + bars[i - 1].close + bars[i - 2].close) / 3), 'fungsi blok dengan ta.* di dalamnya');
  ok(r.plots[5].values[5] === 15, 'argumen bernama untuk fungsi user');
}

console.log('Input override');
{
  const src = `indicator("t")\nlen = input.int(5, "Len")\nplot(ta.sma(close, len))`;
  const a = run(src), b = run(src, { Len: 10 });
  ok(a.inputs.length === 1 && a.inputs[0].defval === 5, 'input terdeteksi');
  ok(Number.isNaN(b.plots[0].values[8]) && !Number.isNaN(a.plots[0].values[8]), 'override input dipakai');
}

console.log('Backtest');
{
  // beli di bar 10, tutup di bar 20 -> isi di open bar 11 & open bar 21
  const r = run(`strategy("t", initial_capital=1000)
if bar_index == 10
    strategy.entry("L", strategy.long, qty=2)
if bar_index == 20
    strategy.close("L")`);
  const t = r.strategy.trades[0];
  ok(r.strategy.trades.length === 1, 'satu trade');
  ok(t.entryPrice === bars[11].open && t.exitPrice === bars[21].open, 'isi di open bar berikutnya');
  ok(near(t.pnl, (bars[21].open - bars[11].open) * 2), 'PnL benar');
  ok(near(r.strategy.equity[bars.length - 1], 1000 + t.pnl), 'equity akhir benar');
}
{
  // reversal long -> short
  const r = run(`strategy("t")
if bar_index == 10
    strategy.entry("L", strategy.long)
if bar_index == 20
    strategy.entry("S", strategy.short)`);
  ok(r.strategy.trades.length === 1 && r.strategy.openTrades.length === 1 && r.strategy.openTrades[0].dir === -1, 'reversal long ke short');
}
{
  // stop loss / take profit
  const r = run(`strategy("t")
if bar_index == 10
    strategy.entry("L", strategy.long)
    strategy.exit("X", "L", stop=close * 0.97, limit=close * 1.03)`);
  const t = r.strategy.trades[0];
  ok(t && (near(t.exitPrice, bars[10].close * 0.97) || near(t.exitPrice, bars[10].close * 1.03) || t.exitPrice === bars[t.exitBar].open), 'exit stop/limit terisi di level yang benar');
  // verifikasi tidak ada bar sebelum exit yang menyentuh level
  let hitEarlier = false;
  for (let k = 11; k < t.exitBar; k++) if (bars[k].low <= bars[10].close * 0.97 || bars[k].high >= bars[10].close * 1.03) hitEarlier = true;
  ok(!hitEarlier, 'exit pada bar pertama yang menyentuh level');
}
{
  // partial exit: qty_percent dihitung dari ukuran awal entry, SL berlaku untuk sisa posisi
  const t0 = Date.UTC(2024, 0, 1);
  const mk = (o, h, l, c) => ({ open: o, high: h, low: l, close: c, volume: 1 });
  const path = [mk(100, 100.5, 99.5, 100), mk(100, 100.5, 99.5, 100), mk(100, 101.5, 99.8, 101), mk(101, 102.5, 100.8, 102), mk(102, 102.2, 98, 98.5), mk(98.5, 99, 98, 98.5)];
  const pb = path.map((b, k) => ({ ...b, time: t0 + k * 3600e3 }));
  const src = `strategy("t", initial_capital=1000)
if bar_index == 0
    strategy.entry("L", strategy.long, qty=10)
    strategy.exit("T1", "L", qty_percent=50, limit=101, stop=99)
    strategy.exit("T2", "L", qty_percent=30, limit=102, stop=99)
    strategy.exit("T3", "L", qty_percent=100, limit=110, stop=99)`;
  const r = Pine.run(Pine.compile(src), pb, { timeframe: '1h' });
  const tr = r.strategy.trades;
  const q = (id) => tr.filter((t) => t.exitId === id).reduce((a, t) => a + t.qty, 0);
  ok(tr.length === 3 && near(q('T1'), 5) && near(q('T2'), 3) && near(q('T3'), 2), `partial exit 50/30/sisa (${tr.map((t) => t.exitId + ':' + t.qty).join(' ')})`);
  ok(near(tr.find((t) => t.exitId === 'T1').exitPrice, 101) && near(tr.find((t) => t.exitId === 'T2').exitPrice, 102) && near(tr.find((t) => t.exitId === 'T3').exitPrice, 99), 'harga TP1, TP2, lalu SL untuk sisa');
  ok(r.strategy.openTrades.length === 0, 'posisi tertutup penuh');
}
{
  // komisi persen
  const r = run(`strategy("t", commission_value=0.1)
if bar_index == 10
    strategy.entry("L", strategy.long, qty=1)
if bar_index == 12
    strategy.close("L")`);
  const t = r.strategy.trades[0];
  const exp = t.exitPrice - t.entryPrice - 0.001 * (t.entryPrice + t.exitPrice);
  ok(near(t.pnl, exp), 'komisi dihitung');
}


console.log('switch, if-ekspresi, for-in, array, method');
{
  const r = run(`indicator("t")
mode = input.string("b", "Mode")
v = switch mode
    "a" => 1
    "b" => 2
    => 3
w = if close > open
    10
else
    -10
k = switch
    close > open => 1
    => 0
var arr = array.new_float()
arr.push(close)
if arr.size() > 3
    arr.shift()
total = 0.0
for x in arr
    total += x
cnt = 0
for [i, x] in arr
    cnt += i
s = 0
switch mode
    "b" =>
        s := 5
    => s := 7
array<float> ga = array.new<float>(2, 1.5)
plot(v)
plot(w)
plot(total)
plot(cnt)
plot(s)
plot(array.sum(ga))
plot(k)`);
  ok(!r.error, 'kompilasi & jalan ' + (r.error || ''));
  ok(r.plots[0].values[5] === 2, 'switch dengan subjek');
  ok(r.plots[1].values[10] === (bars[10].close > bars[10].open ? 10 : -10), 'if sebagai ekspresi');
  ok(near(r.plots[2].values[50], bars[48].close + bars[49].close + bars[50].close), 'array + method push/shift/size + for-in');
  ok(r.plots[3].values[50] === 3, 'for [i, x] in array');
  ok(r.plots[4].values[5] === 5, 'switch sebagai statement dengan blok');
  ok(r.plots[5].values[5] === 3, 'array.new<float>(2, 1.5) + tipe generik');
  ok(r.plots[6].values[10] === (bars[10].close > bars[10].open ? 1 : 0), 'switch tanpa subjek');
}

console.log('Timeframe & HTF');
{
  const r = run(`indicator("t")
newDay = timeframe.change("D")
var float dHigh = na
var float prevDayHigh = na
if newDay
    prevDayHigh := dHigh
    dHigh := high
else
    dHigh := math.max(dHigh, high)
sec = request.security(syminfo.tickerid, "D", high[1], lookahead = barmerge.lookahead_on)
plot(prevDayHigh)
plot(sec)
plot(timeframe.in_seconds())
plot(timeframe.in_seconds("240"))`);
  ok(!r.error, 'jalan ' + (r.error || ''));
  const i = 300;
  const day = Math.floor(bars[i].time / 864e5);
  const prevDay = bars.filter((b) => Math.floor(b.time / 864e5) === day - 1);
  const ph = Math.max(...prevDay.map((b) => b.high));
  ok(near(r.plots[0].values[i], ph), 'high hari sebelumnya via timeframe.change');
  ok(near(r.plots[1].values[i], ph), 'request.security HTF high[1] (tanpa repaint)');
  ok(r.plots[2].values[0] === 3600 && r.plots[3].values[0] === 14400, 'timeframe.in_seconds');
}

console.log('Objek gambar (box/line/label/table) & replay');
{
  const r = run(`indicator("t", overlay=true, max_boxes_count=3)
var box b = na
if bar_index == 10
    b := box.new(bar_index, high, bar_index, low, bgcolor=color.new(color.red, 80))
if bar_index > 10 and bar_index <= 20
    b.set_right(bar_index)
if bar_index % 50 == 0
    box.new(bar_index, high, bar_index + 5, low)
l = label.new(bar_index, high, "x")
label.delete(l[1])
var t = table.new(position.top_right, 2, 2)
if barstate.islast
    table.cell(t, 0, 0, "Bias", text_color=color.white)`);
  ok(!r.error, 'jalan ' + (r.error || ''));
  const Ext = globalThis.LunaPineExt;
  const b0 = r.drawings.box.find((x) => x.created === 10);
  ok(Ext.stateAt(b0, 15).right === 15 && Ext.stateAt(b0, 9) === null && b0.props.right === 20, 'riwayat box per bar (aman untuk replay)');
  ok(r.drawings.box.filter((x) => x.deleted === null).length === 3, 'batas max_boxes_count menghapus yang paling lama');
  const visibleLabels = r.drawings.label.filter((x) => Ext.stateAt(x, 100));
  ok(visibleLabels.length === 1, 'label.delete(l[1]) — hanya label terbaru yang tampil');
  ok(r.drawings.table[0].props['cell:0:0'].text === 'Bias' && !Ext.stateAt(r.drawings.table[0], 100)['cell:0:0'], 'sel tabel muncul hanya mulai bar terakhir');
}


console.log('SATTAM CRT+TBS');
{
  const CRT = require('../js/scripts-crt.js');
  // random walk dengan jalur intrabar yang konsisten, 1 jam
  let p = 50000, seed = 11;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const rwBars = [];
  for (let i = 0; i < 3000; i++) {
    const o = p; let h = p, l = p;
    for (let k = 0; k < 30; k++) { p *= 1 + (rnd() - 0.5) * 0.003; h = Math.max(h, p); l = Math.min(l, p); }
    rwBars.push({ time: Date.UTC(2024, 0, 1) + i * 3600e3, open: o, high: h, low: l, close: p, volume: 100 });
  }
  const runOn = (src, b, inputs) => Pine.run(Pine.compile(src), b, { timeframe: '1h', inputs });
  const ind = runOn(CRT.indicator, rwBars);
  // default strategy sudah di-tuning (sangat selektif); uji mesin trade dengan filter longgar
  const st = runOn(CRT.strategy, rwBars, { 'Entry Model': 'All', 'Kill Zones Only (New York time)': false });
  ok(!ind.error && !st.error, 'indikator & strategy jalan ' + (ind.error || st.error || ''));
  const sigs = (r, upto) => r.drawings.label.filter((l) => /^(SELL|BUY)/.test(l.props.text) && l.created < upto).map((l) => l.created + ':' + l.props.text);
  ok(sigs(ind, 1e9).length > 5, `sinyal muncul (${sigs(ind, 1e9).length})`);
  ok(st.strategy.trades.length > 5, `strategy menghasilkan trade (${st.strategy.trades.length})`);
  const K = 2000;
  const cut = runOn(CRT.indicator, rwBars.slice(0, K));
  ok(JSON.stringify(sigs(cut, K)) === JSON.stringify(sigs(ind, K)), 'tidak repaint: sinyal sebelum bar K sama dengan/ tanpa data masa depan');
  const tbl = ind.drawings.table[0];
  ok(tbl && tbl.props['cell:0:0'].text === 'HTF' && tbl.props['cell:1:0'].text === '1D', 'tabel status + HTF otomatis 1H → 1D');
  // ⑨ EMA 48/380: filter tren & sweep di EMA hanya MENYARING sinyal (subset), tanpa repaint
  const pr = '\nplot(sigBull ? 1 : sigBear ? -1 : 0, "zSig")\nplot(emaT4, "zT4")\nplot(bearEMA ? 1 : 0, "zBE")\nplot(bullEMA ? 1 : 0, "zBU")\n';
  const base = { 'Entry Model': 'All', 'Kill Zones Only (New York time)': false, 'Require Key Level': false, 'HTF Mode': 'Manual', 'Manual HTF': '240' };
  const lt = []; for (let i = 0; i < rwBars.length; i++) lt.push(rwBars[i]);
  const s0 = runOn(CRT.indicator + pr, lt, base), sF = runOn(CRT.indicator + pr, lt, Object.assign({}, base, { 'Filter tren EMA 48/380': 'Searah 4H' })), sL = runOn(CRT.indicator + pr, lt, Object.assign({}, base, { 'Sweep harus di EMA 48/380 (4H/1H)': true }));
  const V = (r, n) => r.plots.find((x) => x.title === n).values;
  const n0 = V(s0, 'zSig').filter((v) => v).length, nF = V(sF, 'zSig').filter((v) => v).length, nL = V(sL, 'zSig').filter((v) => v).length;
  ok(!s0.error && !sF.error && !sL.error && nF < n0 && nL < n0 && nL > 0, `filter EMA menyaring sinyal CRT (${n0} → tren 4H ${nF}, sweep di EMA ${nL})`);
  ok(V(sF, 'zSig').every((v, i) => !v || v === V(sF, 'zT4')[i]), 'filter tren EMA 4H: semua sinyal searah EMA48 vs EMA380 4H');
  ok(V(sL, 'zSig').every((v, i) => !v || (v > 0 ? V(sL, 'zBU')[i] : V(sL, 'zBE')[i]) === 1), 'sweep di EMA: setiap sinyal punya sweep yang menyentuh EMA 48/380');
}

console.log('EMA Cross: entry zona EMA, SL swing, TP zona');
{
  const { LEGACY } = require('../js/scripts.js');
  const ema = EXAMPLES.find((e) => e.key === 'ema-cross');
  const olds = LEGACY['ema-cross'];
  ok(olds.every((o) => o.trim() !== ema.code.trim()) && olds.some((o) => /strategy\.close\("Long"\)\n?$/.test(o.trim() + '\n')), `${olds.length} versi lama disimpan untuk migrasi otomatis`);
  let p = 100, seed = 5;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const wb = [];
  for (let i = 0; i < 4000; i++) {
    const o = p; let h = p, l = p;
    for (let k = 0; k < 20; k++) { p *= 1 + (rnd() - 0.5) * 0.004 + 0.00002; h = Math.max(h, p); l = Math.min(l, p); }
    wb.push({ time: Date.UTC(2024, 0, 1) + i * 3600e3, open: o, high: h, low: l, close: p, volume: 1 });
  }
  const src = ema.code + '\nplot(sDir != 0 and not sLive ? sSL : na, "zSL")\nplot(sDir != 0 and not sLive ? sE : na, "zE")\nplot(sT1, "zT1")\nplot(sT2, "zT2")\nplot(sT3, "zT3")\nplot(sDir, "zD")';
  const r = Pine.run(Pine.compile(src), wb, { timeframe: '1h' });
  ok(!r.error, 'jalan tanpa error ' + (r.error || ''));
  const P = (n) => r.plots.find((x) => x.title === n).values;
  const [sl, en, t1, t2, t3, dir] = ['zSL', 'zE', 'zT1', 'zT2', 'zT3', 'zD'].map(P);
  let pend = 0, bad = 0;
  for (let i = 0; i < wb.length; i++) {
    if (!(dir[i] > 0) || isNaN(en[i]) || isNaN(sl[i])) continue;
    pend++;
    if (!(sl[i] < en[i] && en[i] < t1[i] && t1[i] < t2[i] && t2[i] < t3[i])) bad++;
  }
  ok(pend > 20 && bad === 0, `long: SL < entry < TP1 < TP2 < TP3 di setiap bar menunggu (${pend} bar, ${bad} salah)`);
  const ids = new Set(r.strategy.trades.map((t) => t.exitId));
  ok(r.strategy.trades.length > 5 && ids.has('TP1') && ids.has('TP3'), `trade terjadi dengan partial exit (${r.strategy.trades.length} potongan)`);
  const sl1 = r.strategy.trades.filter((t) => t.exitId === 'TP1' && t.exitPrice < t.entryPrice);
  ok(sl1.every((t) => t.dir > 0), 'semua stop-out berada di bawah harga entry (long)');
}

console.log('MyTT: rumus KDJ / DMI / BBI & rencana trade');
{
  const M = require('../js/scripts-mytt.js');
  const wb = [];
  let p = 50, seed = 9;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 3000; i++) {
    const o = p; let h = p, l = p;
    for (let k = 0; k < 20; k++) { p *= 1 + (rnd() - 0.5) * 0.004 + 0.00001; h = Math.max(h, p); l = Math.min(l, p); }
    wb.push({ time: Date.UTC(2024, 0, 1) + i * 3600e3, open: o, high: h, low: l, close: p, volume: 1 });
  }
  const ri = Pine.run(Pine.compile(M.indicator + '\nplot(bbi, "zBBI")'), wb, { timeframe: '1h' });
  ok(!ri.error, 'indikator jalan ' + (ri.error || ''));
  const P = (r, n) => r.plots.find((x) => x.title === n).values;
  // referensi manual (definisi MyTT): EMA ala pandas adjust=False, SUM/MA rolling
  const C = wb.map((b) => b.close), H = wb.map((b) => b.high), L = wb.map((b) => b.low), n = wb.length;
  const ema = (x, len) => { const a = 2 / (len + 1); const o = []; let prev; for (let i = 0; i < x.length; i++) { if (isNaN(x[i])) { o.push(NaN); continue; } prev = prev === undefined ? x[i] : a * x[i] + (1 - a) * prev; o.push(prev); } return o; };
  const roll = (x, len, f) => x.map((_, i) => (i < len - 1 ? NaN : f(x.slice(i - len + 1, i + 1))));
  const sum = (a) => a.reduce((s, v) => s + v, 0);
  const rsv = C.map((c, i) => { if (i < 8) return NaN; const lo = Math.min(...L.slice(i - 8, i + 1)), hi = Math.max(...H.slice(i - 8, i + 1)); return ((c - lo) / (hi - lo)) * 100; });
  const K = ema(rsv, 5), D = ema(K, 5), J = K.map((k, i) => 3 * k - 2 * D[i]);
  const tr = C.map((c, i) => (i ? Math.max(H[i] - L[i], Math.abs(H[i] - C[i - 1]), Math.abs(L[i] - C[i - 1])) : H[i] - L[i]));
  const hd = H.map((h, i) => (i ? h - H[i - 1] : 0)), ld = L.map((l, i) => (i ? L[i - 1] - l : 0));
  const TR = roll(tr, 14, sum), DMP = roll(hd.map((v, i) => (v > 0 && v > ld[i] ? v : 0)), 14, sum), DMM = roll(ld.map((v, i) => (v > 0 && v > hd[i] ? v : 0)), 14, sum);
  const PDI = DMP.map((v, i) => (v * 100) / TR[i]), MDI = DMM.map((v, i) => (v * 100) / TR[i]);
  const ADX = roll(PDI.map((v, i) => (Math.abs(MDI[i] - v) / (v + MDI[i])) * 100), 6, (a) => sum(a) / 6);
  const BBI = C.map((_, i) => [3, 6, 12, 20].reduce((s, m) => s + (i < m - 1 ? NaN : sum(C.slice(i - m + 1, i + 1)) / m), 0) / 4);
  const maxDiff = (a, b) => { let m = 0; for (let i = n - 500; i < n; i++) m = Math.max(m, Math.abs(a[i] - b[i])); return m; };
  ok(maxDiff(P(ri, 'K'), K) < 1e-6 && maxDiff(P(ri, 'D'), D) < 1e-6 && maxDiff(P(ri, 'J'), J) < 1e-6, 'KDJ sama dengan rumus MyTT');
  ok(maxDiff(P(ri, 'PDI'), PDI) < 1e-6 && maxDiff(P(ri, 'MDI'), MDI) < 1e-6 && maxDiff(P(ri, 'ADX'), ADX) < 1e-6, 'DMI (PDI/MDI/ADX) sama dengan rumus MyTT');
  ok(maxDiff(P(ri, 'zBBI'), BBI) < 1e-9, 'BBI sama dengan rumus MyTT');

  const rs = Pine.run(Pine.compile(M.strategy + '\nplot(newSetup ? tDir : na, "zD")\nplot(tSL, "zSL")\nplot(tE, "zE")\nplot(tT1, "z1")\nplot(tT2, "z2")\nplot(tT3, "z3")'), wb, { timeframe: '1h', inputs: { 'Izinkan Short': true } });
  ok(!rs.error, 'strategy jalan ' + (rs.error || ''));
  const [d, sl, e, t1, t2, t3] = ['zD', 'zSL', 'zE', 'z1', 'z2', 'z3'].map((k) => P(rs, k));
  let cnt = 0, bad = 0;
  for (let i = 0; i < n; i++) {
    if (!(d[i] === 1 || d[i] === -1)) continue;
    cnt++;
    const s = d[i];
    if (!((e[i] - sl[i]) * s > 0 && (t1[i] - e[i]) * s > 0 && (t2[i] - t1[i]) * s > 0 && (t3[i] - t2[i]) * s > 0)) bad++;
  }
  ok(cnt > 5 && bad === 0, `setiap setup: SL di sisi rugi, TP1 < TP2 < TP3 searah (${cnt} setup, ${bad} salah)`);
}

console.log('Cycle Low (DCL / WCL) — tanpa repaint');
{
  const CY = require('../js/scripts-cycle.js');
  // harga sintetis harian: siklus 60 hari + siklus 180 hari + tren naik kecil + noise
  let seed = 3;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const cb = [];
  for (let i = 0; i < 1500; i++) {
    const c = 100 * (1 + 0.0004 * i) * (1 + 0.08 * Math.sin((2 * Math.PI * (i - 15)) / 60) + 0.12 * Math.sin((2 * Math.PI * (i - 45)) / 180)) * (1 + (rnd() - 0.5) * 0.01);
    const o = i ? cb[i - 1].close : c;
    cb.push({ time: Date.UTC(2020, 0, 1) + i * 86400e3, open: o, high: Math.max(o, c) * 1.003, low: Math.min(o, c) * 0.997, close: c, volume: 1 });
  }
  const comp = Pine.compile(CY.indicator);
  const r = Pine.run(comp, cb, { timeframe: '1D' });
  ok(!r.error, 'jalan tanpa error ' + (r.error || ''));
  const isCyc = (l) => !l.deleted && /^(DCL|WCL)$/.test(l.props.text);
  const perm = r.drawings.label.filter(isCyc);
  const D = perm.filter((l) => l.props.text === 'DCL').map((l) => l.props.x).sort((a, b) => a - b);
  const W = perm.filter((l) => l.props.text === 'WCL').map((l) => l.props.x).sort((a, b) => a - b);
  const gaps = D.slice(1).map((x, k) => x - D[k]);
  const avg = gaps.reduce((a, b) => a + b, 0) / gaps.length;
  ok(D.length >= 20 && avg > 50 && avg < 70, `DCL terdeteksi tiap ±60 hari (${D.length} low, rata-rata ${avg.toFixed(1)} hari)`);
  const isTrough = (x) => cb.slice(Math.max(0, x - 10), x + 11).every((b) => b.low >= cb[x].low);
  ok(D.filter(isTrough).length >= D.length * 0.8, 'DCL berada di lembah harga (low terendah ±10 hari)');
  const wg = W.slice(1).map((x, k) => x - W[k]);
  ok(W.length >= 5 && wg.every((g) => g >= 100 && g <= 260), `WCL terdeteksi (${W.length}×, jarak ${wg.join('/')} hari)`);
  ok(perm.every((l) => l.created > l.props.x), 'label ditulis setelah low terkonfirmasi (tidak ada label di candle yang sedang berjalan)');
  // tanpa repaint: label dari data terpotong == label run penuh yang sudah ditulis sebelum titik potong
  let same = 0;
  for (const cut of [400, 700, 1000, 1300]) {
    const a = Pine.run(comp, cb.slice(0, cut), { timeframe: '1D' }).drawings.label.filter(isCyc).map((l) => l.props.text + l.props.x + ':' + l.props.y).sort().join();
    const b = perm.filter((l) => l.created < cut).map((l) => l.props.text + l.props.x + ':' + l.props.y).sort().join();
    if (a === b) same++;
  }
  ok(same === 4, `tanpa repaint: label identik di ${same}/4 titik potong`);
  // prediksi harga & waktu DCL / WCL berikutnya
  const pr = r.drawings.label.filter((l) => !l.deleted && /Prediksi/.test(l.props.tooltip));
  const pD = pr.find((l) => l.props.text.startsWith('DCL ')), pW = pr.find((l) => l.props.text.startsWith('WCL '));
  ok(pD && pW && pD.props.x >= cb.length && /\d/.test(pD.props.text) && pD.props.y > 0, `prediksi DCL & WCL berikutnya: "${pD && pD.props.text}", "${pW && pW.props.text}"`);
  const pv = r.plots.find((p) => p.title === 'Prediksi harga DCL').values;
  const err = [];
  for (let k = 4; k < D.length; k++) { if (D[k] < D[k - 1] + 40) continue; const v = pv[D[k - 1] + 40]; err.push(Math.abs(cb[D[k]].low - v) / v * 100); }
  err.sort((a, b) => a - b);
  ok(err.length >= 10 && err[err.length >> 1] < 8, `prediksi harga DCL (terkunci di awal band): selisih median ${err[err.length >> 1].toFixed(1)}% dari ${err.length} siklus`);
  // status siklus: ✕ DCL ditembus / ⚠ translasi kiri ditulis di candle kejadian (tanpa repaint)
  const stl = r.drawings.label.filter((l) => !l.deleted && /^(✕|⚠) /.test(l.props.text));
  const brk = stl.filter((l) => l.props.text.startsWith('✕'));
  ok(brk.length > 0 && stl.every((l) => l.created === l.props.x) && brk.every((l) => { const ds = D.filter((x) => x < l.props.x); const prevD = ds[ds.length - 1]; return prevD !== undefined && cb[l.props.x].low < cb[prevD].low; }), `penanda status siklus ditulis saat terjadi (${brk.length}× DCL ditembus, ${stl.length - brk.length}× translasi kiri)`);
  const tip = (sym) => (Pine.run(comp, cb, { timeframe: '1D', symbol: sym }).drawings.label.find((l) => !l.deleted && /Prediksi DCL/.test(l.props.tooltip)) || { props: { tooltip: '' } }).props.tooltip;
  ok(/preset ENAUSDT/.test(tip('ENAUSDT')) && !/preset ENAUSDT/.test(tip('BTCUSDT')), 'preset Auto: ENAUSDT memakai setelan hasil tuning ENA, koin lain tidak');
  // penanda news: di candle tanggal kejadian, FOMC/unlock hanya jika dinyalakan, jadwal mendatang di area masa depan
  const news = r.drawings.label.filter((l) => !l.deleted && /·/.test(l.props.tooltip || '') && !/^(DCL|WCL)/.test(l.props.text));
  const covid = news.find((l) => /COVID/.test(l.props.text));
  ok(covid && cb[covid.props.x].time === Date.UTC(2020, 2, 12) && !news.some((l) => /FOMC|Unlock/.test(l.props.text)), `penanda news di candle kejadian (${news.length} penanda, COVID di ${covid ? new Date(cb[covid.props.x].time).toISOString().slice(0, 10) : '?'})`);
  const rf = Pine.run(comp, cb, { timeframe: '1D', inputs: { 'FOMC (rapat suku bunga The Fed)': true } }).drawings.label.filter((l) => !l.deleted && /FOMC/.test(l.props.text));
  ok(rf.length > 10 && rf.every((l) => l.props.x >= cb.length) && rf.some((l) => /akan datang/.test(l.props.tooltip)), `FOMC (dinyalakan) tampil sebagai jadwal mendatang (${rf.length} penanda)`);
}

console.log('KLCTZ [PhenLabs]: zona confluence, rencana & strategy');
{
  const K = require('../js/scripts-klctz.js');
  ok(JSON.stringify(globalThis.LunaPineExt.makeArray().sort_indices([3, 1, 2, 1], 'ascending')) === '[1,3,2,0]', 'array.sort_indices ascending (stabil)');
  const wb = [];
  let p = 20, seed = 21;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 2500; i++) {
    const o = p; let h = p, l = p;
    for (let k = 0; k < 12; k++) { p *= 1 + (rnd() - 0.5) * 0.006; h = Math.max(h, p); l = Math.min(l, p); }
    wb.push({ time: Date.UTC(2025, 0, 6) + i * 3600e3, open: o, high: h, low: l, close: p, volume: 100 + rnd() * 900 });
  }
  const probe = '\nplot(pdh, "zPDH")\nplot(pdl, "zPDL")\nplot(pdc, "zPDC")\nplot(dP, "zP")\nplot(dR1, "zR1")\nplot(dOpenDir, "zDir")\nplot(dE, "zE")\nplot(dS, "zS")\nplot(dT1, "zT1")\nplot(dT2, "zT2")\nplot(dT3, "zT3")\nplot(lg(dispIdx, F_TR), "zTR")\nplot(dlActive ? 1 : 0, "zAct")\n';
  const ri = Pine.run(Pine.compile(K.indicator + probe), wb, { timeframe: '1h', symbol: 'TEST' });
  ok(!ri.error && ri.drawings.table.length === 1, 'indikator jalan + dashboard ' + (ri.error || ''));
  const P = (r, n) => r.plots.find((x) => x.title === n).values;
  // pivot harian dari candle harian SEBELUMNYA (tanpa repaint)
  const i = 1000, day = Math.floor(wb[i].time / 864e5) - 1;
  const prev = wb.filter((b) => Math.floor(b.time / 864e5) === day);
  const H = Math.max(...prev.map((b) => b.high)), Lo = Math.min(...prev.map((b) => b.low)), C = prev[prev.length - 1].close, piv = (H + Lo + C) / 3;
  ok(Math.abs(P(ri, 'zPDH')[i] - H) < 1e-9 && Math.abs(P(ri, 'zPDL')[i] - Lo) < 1e-9 && Math.abs(P(ri, 'zPDC')[i] - C) < 1e-9, 'PDH/PDL/PDC = candle harian kemarin');
  ok(Math.abs(P(ri, 'zP')[i] - piv) < 1e-9 && Math.abs(P(ri, 'zR1')[i] - (2 * piv - Lo)) < 1e-9, 'pivot Traditional P & R1 sesuai rumus');
  const dir = P(ri, 'zDir');
  let n = 0, bad = 0;
  for (let k = 0; k < wb.length; k++) {
    if (!dir[k]) continue;
    n++;
    const d = dir[k], v = [P(ri, 'zS')[k], P(ri, 'zE')[k], P(ri, 'zT1')[k], P(ri, 'zT2')[k], P(ri, 'zT3')[k]].map((x) => x * d);
    if (!(v[0] < v[1] && v[1] < v[2] && v[2] < v[3] && v[3] <= v[4] + 1e-12)) bad++;
  }
  ok(n > 10 && bad === 0, `rencana: SL < Entry < TP1 < TP2 ≤ TP3 (${n} sinyal, ${bad} salah)`);
  // tanpa repaint: sinyal di data terpotong sama dengan data penuh
  const cut = 1800;
  const rc = Pine.run(Pine.compile(K.indicator + probe), wb.slice(0, cut), { timeframe: '1h', symbol: 'TEST' });
  ok(P(rc, 'zDir').every((v, k) => v === dir[k]), 'sinyal tidak berubah saat data bertambah (tanpa repaint)');
  // strategy: order mengikuti ledger profil yang ditampilkan
  const rs = Pine.run(Pine.compile(K.strategy + probe), wb, { timeframe: '1h', symbol: 'TEST' });
  ok(!rs.error, 'strategy jalan ' + (rs.error || ''));
  const posN = new Set(rs.strategy.trades.map((t) => t.entryBar)).size + (rs.strategy.openTrades.length ? 1 : 0);
  const led = P(rs, 'zTR')[wb.length - 1] + P(rs, 'zAct')[wb.length - 1];
  ok(posN > 10 && Math.abs(posN - led) <= 1, `jumlah posisi broker = rencana ledger (${posN} vs ${led})`);
  const ids = new Set(rs.strategy.trades.map((t) => t.exitId));
  ok(ids.has('TP1') && ids.has('TP2') && ids.has('TP3'), 'scale-out TP1 / TP2 / TP3');
  const sig = [];
  for (let m = 1500; m < 2500; m += 23) { const s = require('../js/scanner.js').evaluate('klctz', K.strategy, wb.slice(0, m), { tf: '1h', symbol: 'TEST', maxAge: 5 }); if (s) sig.push(s); }
  ok(sig.length > 0 && sig.every((s) => s.rr1 > 0 && s.rr2 > s.rr1 && s.rr3 >= s.rr2), `scanner KLCTZ: ${sig.length} sinyal dengan R:R berurutan`);
}

console.log('KLCTZ: preset Optimasi Luna 4H + filter ML');
{
  const K = require('../js/scripts-klctz.js');
  const wb = [];
  let p = 30, seed = 77;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 4000; i++) {
    const o = p; let h = p, l = p;
    for (let k = 0; k < 12; k++) { p *= 1 + (rnd() - 0.5) * 0.01; h = Math.max(h, p); l = Math.min(l, p); }
    wb.push({ time: Date.UTC(2023, 0, 2) + i * 4 * 3600e3, open: o, high: h, low: l, close: p, volume: 100 + rnd() * 900 });
  }
  const pr = '\nplot(dOpenDir, "zDir")\nplot(dProb, "zProb")\n';
  const run = (inputs) => Pine.run(Pine.compile(K.strategy + pr), wb, { timeframe: '4h', symbol: 'TEST', inputs });
  const on = run({}), off = run({ 'Filter ML': 'Mati' });
  ok(!on.error && !off.error, 'strategy default (Optimasi 4H + ML) jalan ' + (on.error || off.error || ''));
  const n = (r) => r.plots.find((x) => x.title === 'zDir').values.filter((v) => v).length;
  ok(n(off) > n(on) && n(on) > 0, `filter ML menyaring setup (${n(off)} → ${n(on)})`);
  const pv = on.plots.find((x) => x.title === 'zProb').values.filter((v) => !Number.isNaN(v));
  ok(pv.length === n(on) && pv.every((v) => v >= 1 / (1 + Math.exp(-(-0.4841))) - 1e-3 && v < 1), `peluang ML tiap setup ≥ ambang (${pv.length} setup)`);
  const lbl = on.drawings.label.map((o) => String(o.props.text)).filter((t) => /^(BUY|SELL)/.test(t));
  ok(lbl.length > 0 && lbl.every((t) => /BREAKOUT/.test(t) && /ML \d+%/.test(t)), 'label sinyal: hanya BREAKOUT + peluang ML');
}

console.log('Luna AI Signal 1H (model ML)');
{
  const AI = require('../js/scripts-ai.js');
  const wb = [];
  let p = 10, seed = 5;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 2600; i++) {
    const o = p; let h = p, l = p;
    for (let k = 0; k < 6; k++) { p *= 1 + (rnd() - 0.5) * 0.008; h = Math.max(h, p); l = Math.min(l, p); }
    wb.push({ time: Date.UTC(2025, 0, 6) + i * 3600e3, open: o, high: h, low: l, close: p, volume: 100 + rnd() * 900 });
  }
  ok(AI.MODEL.trees.length === 150 && AI.MODEL.thK > AI.MODEL.thN, 'model v2: 150 pohon + 2 ambang');
  const pr = '\nplot(newDir, "zDir")\nplot(pScore, "zSc")\n';
  const ri = Pine.run(Pine.compile(AI.indicator + pr), wb, { timeframe: '1h', symbol: 'TEST', inputs: { 'Tingkat seleksi': 'Normal (±8% skor teratas)', 'Lewati bila biaya > (R)': 0 } });
  ok(!ri.error && ri.drawings.table.length === 1, 'indikator jalan + panel ' + (ri.error || ''));
  const dir = ri.plots.find((x) => x.title === 'zDir').values, sc = ri.plots.find((x) => x.title === 'zSc').values;
  const sig = dir.map((v, i) => [v, i]).filter(([v]) => v);
  ok(sig.length > 0 && sig.every(([, i]) => i >= 800 && sc[i] >= AI.MODEL.thN - 1e-12), `sinyal hanya setelah pemanasan & skor ≥ ambang (${sig.length} sinyal)`);
  const rc = Pine.run(Pine.compile(AI.indicator + pr), wb.slice(0, 2000), { timeframe: '1h', symbol: 'TEST' });
  ok(rc.plots.find((x) => x.title === 'zDir').values.every((v, k) => v === dir[k]), 'tanpa repaint: sinyal sama saat data bertambah');
  const rs = Pine.run(Pine.compile(AI.strategy + pr), wb, { timeframe: '1h', symbol: 'TEST' });
  const pos = new Set(rs.strategy.trades.map((t) => t.entryBar)).size + (rs.strategy.openTrades.length ? 1 : 0);
  ok(!rs.error && Math.abs(pos - sig.length) <= 1, `strategy: posisi broker = sinyal (${pos} vs ${sig.length})`);
  const rf = Pine.run(Pine.compile(AI.indicator + pr), wb, { timeframe: '1h', symbol: 'TEST', inputs: { 'Komisi per sisi (%) — statistik & filter biaya': 3 } });
  ok(rf.plots.find((x) => x.title === 'zDir').values.every((v) => !v), 'filter biaya: komisi terlalu besar dibanding SL → trade dilewati');
}

console.log('Luna AI: volume spike (relatif jam yang sama) & SNDK');
{
  const AI = require('../js/scripts-ai.js');
  const wb = [];
  let p = 100, seed = 11;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 3000; i++) {
    const hr = i % 96; // 15m: slot 52 = "pembukaan bursa" bervolume tinggi setiap hari (bukan spike)
    const o = p; let h = p, l = p;
    for (let k = 0; k < 4; k++) { p *= 1 + (rnd() - 0.5) * 0.004; h = Math.max(h, p); l = Math.min(l, p); }
    let v = 100 * (0.8 + rnd() * 0.4) * (hr === 52 ? 8 : 1);
    if (i % 173 === 0 && i > 1000) { v *= 9; p = o * (rnd() > 0.5 ? 1.01 : 0.99); h = Math.max(h, o, p); l = Math.min(l, o, p); }
    wb.push({ time: Date.UTC(2026, 3, 6) + i * 900e3, open: o, high: h, low: l, close: p, volume: v });
  }
  const pr = '\nplot(newDir, "zDir")\nplot(vMult, "zV")\nplot(pKind, "zK")\n';
  const r = Pine.run(Pine.compile(AI.strategy + pr), wb, { timeframe: '15m', symbol: 'SNDKUSDT', inputs: { 'Sumber sinyal': 'Volume Spike saja' } });
  ok(!r.error, 'jalan di SNDKUSDT 15m ' + (r.error || ''));
  const P = (n) => r.plots.find((x) => x.title === n).values;
  const vm = P('zV'), dir = P('zDir'), kind = P('zK');
  const openBar = wb.map((_, i) => i).filter((i) => i > 1000 && i % 96 === 52);
  ok(openBar.every((i) => vm[i] < 2), 'volume tinggi rutin di jam pembukaan bursa TIDAK dianggap spike');
  const spikes = wb.map((_, i) => i).filter((i) => i > 1000 && i % 173 === 0);
  ok(spikes.every((i) => vm[i] > 5), `spike sungguhan terdeteksi (${spikes.length}×, min ${Math.min(...spikes.map((i) => vm[i])).toFixed(1)}×)`);
  const ent = dir.map((d, i) => [d, i]).filter(([d]) => d);
  ok(ent.length > 0 && ent.every(([d, i]) => kind[i] === 2 && vm[i] >= 5 && d === Math.sign(wb[i].close - wb[i].open)), `mode Volume Spike: entry searah candle spike (${ent.length} entry)`);
  const rc = Pine.run(Pine.compile(AI.strategy + pr), wb.slice(0, 2200), { timeframe: '15m', symbol: 'SNDKUSDT', inputs: { 'Sumber sinyal': 'Volume Spike saja' } });
  ok(rc.plots.find((x) => x.title === 'zDir').values.every((v, k) => v === dir[k]), 'spike tanpa repaint');
  const rb = Pine.run(Pine.compile(AI.strategy + pr), wb, { timeframe: '15m', symbol: 'BTCUSDT' });
  ok(rb.plots.find((x) => x.title === 'zDir').values.every((v) => !v), 'default (AI saja) di 15m: tidak ada entry, spike hanya ditandai');
  const Dd = require('../js/data.js');
  ok(Dd.norm('SANDISKUSDT') === 'SNDKUSDT' && Dd.norm('BTCUSDT') === 'BTCUSDT', 'SANDISKUSDT dialihkan ke simbol Binance SNDKUSDT');
}

console.log('EMA 48/380 MTF: EMA timeframe besar tanpa repaint');
{
  const E = require('../js/scripts-ema.js');
  const wb = [];
  let p = 50, seed = 3;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 9000; i++) {
    const o = p; let h = p, l = p;
    for (let k = 0; k < 3; k++) { p *= 1 + (rnd() - 0.5) * 0.004 + Math.sin(i / 900) * 0.0004; h = Math.max(h, p); l = Math.min(l, p); }
    wb.push({ time: Date.UTC(2026, 0, 1) + i * 900e3, open: o, high: h, low: l, close: p, volume: 100 });
  }
  const r = Pine.run(Pine.compile(E.indicator), wb, { timeframe: '15m', symbol: 'TEST' });
  ok(!r.error && r.drawings.table.length === 1, 'indikator jalan + panel ' + (r.error || ''));
  // referensi: close candle 4H yang sudah selesai → EMA ala Pine (seed SMA)
  const ref = (ms, n) => {
    const closes = [], out = []; let cur = null, v = NaN, s = 0, cnt = 0;
    for (let i = 0; i < wb.length; i++) {
      const b = Math.floor(wb[i].time / ms); if (cur !== null && b !== cur) {} cur = b;
      if ((wb[i].time + 900e3) % ms === 0) { cnt++; const c = wb[i].close; if (cnt <= n) { s += c; if (cnt === n) v = s / n; } else v = (2 / (n + 1)) * c + (1 - 2 / (n + 1)) * v; }
      out.push(v);
    }
    return out;
  };
  const P = (n) => r.plots.find((x) => x.title === n).values;
  const same = (a, b) => a.every((v, i) => (Number.isNaN(v) && Number.isNaN(b[i])) || Math.abs(v - b[i]) < 1e-9);
  ok(same(P('EMA 48 TF besar 1'), ref(144e5, 48)) && same(P('EMA 380 TF besar 1'), ref(144e5, 380)), 'EMA 48/380 4H = EMA dari close candle 4H yang sudah selesai');
  ok(same(P('EMA 48 TF besar 2'), ref(36e5, 48)), 'EMA 48 1H benar');
  const rc = Pine.run(Pine.compile(E.indicator), wb.slice(0, 7000), { timeframe: '15m', symbol: 'TEST' });
  ok(rc.plots.find((x) => x.title === 'EMA 380 TF besar 1').values.every((v, i) => (Number.isNaN(v) && Number.isNaN(P('EMA 380 TF besar 1')[i])) || v === P('EMA 380 TF besar 1')[i]), 'tanpa repaint: nilai sama saat data bertambah');
  const sup = r.shapes.find((x) => x.title === 'Pantul support').hits, a48 = P('EMA 48 TF besar 1'), a380 = P('EMA 380 TF besar 1');
  ok(sup.length > 0 && sup.every((h) => a48[h.i] > a380[h.i]), `pantul support hanya saat tren 4H naik (${sup.length} tanda)`);
  const AI = require('../js/scripts-ai.js');
  const h1 = []; for (let i = 0; i < wb.length; i += 4) { const g = wb.slice(i, i + 4); h1.push({ time: g[0].time, open: g[0].open, high: Math.max(...g.map((x) => x.high)), low: Math.min(...g.map((x) => x.low)), close: g[g.length - 1].close, volume: 400 + (i % 7) * 50 }); }
  const ra = Pine.run(Pine.compile(AI.indicator + '\nplot(newDir, "zDir")\nplot(emaTr, "zTr")\n'), h1, { timeframe: '1h', symbol: 'TEST', inputs: { 'Hanya searah tren EMA 48/380 4H': true, 'Lewati bila biaya > (R)': 0 } });
  const dd = ra.plots.find((x) => x.title === 'zDir').values, tr = ra.plots.find((x) => x.title === 'zTr').values;
  ok(!ra.error && dd.every((d, i) => !d || d === tr[i]), `Luna AI + filter EMA 4H: sinyal selalu searah tren (${dd.filter((d) => d).length} sinyal)`);
}

console.log('Scanner sinyal');
{
  const SC = require('../js/scanner.js');
  const tfMs = 3600e3;
  const mk = (n, now) => Array.from({ length: n }, (_, i) => ({ time: now - (n - i) * tfMs, open: 1, high: 1, low: 1, close: 1, volume: 1 }));
  const now = Date.UTC(2025, 0, 1, 10, 30);
  const open = mk(5, now).concat([{ time: Math.floor(now / tfMs) * tfMs, open: 1, high: 1, low: 1, close: 1, volume: 1 }]);
  ok(SC.closedBars(open, tfMs, now).length === 5 && SC.closedBars(open.slice(0, 5), tfMs, now).length === 5, 'candle yang belum close dibuang');
  let p = 100, seed = 21;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const wb = [];
  for (let i = 0; i < 3000; i++) {
    const o = p; let h = p, l = p;
    for (let k = 0; k < 20; k++) { p *= 1 + (rnd() - 0.5) * 0.004 + 0.00002; h = Math.max(h, p); l = Math.min(l, p); }
    wb.push({ time: Date.UTC(2024, 0, 1) + i * 3600e3, open: o, high: h, low: l, close: p, volume: 1 });
  }
  for (const key of ['ema', 'mytt']) {
    const ad = SC.ADAPTERS[key];
    const code = EXAMPLES.find((e) => e.key === ad.exampleKey).code;
    let n = 0, bad = 0;
    const st = {};
    for (let end = 600; end <= wb.length; end += 5) {
      const s = SC.evaluate(key, code, wb.slice(end - 600, end), { tf: '1h', symbol: 'TESTUSDT' });
      if (!s) continue;
      n++;
      st[s.status] = (st[s.status] || 0) + 1;
      const d = s.dir;
      if (!((s.entry - s.sl) * d > 0 && (s.tp1 - s.entry) * d > 0 && (s.tp2 - s.tp1) * d > 0 && (s.tp3 - s.tp2) * d > 0 && s.age >= 0 && s.key.includes('TESTUSDT'))) bad++;
    }
    ok(n > 3 && bad === 0, `${ad.label}: sinyal terdeteksi dengan level konsisten (${n} titik, ${JSON.stringify(st)}, ${bad} salah)`);
  }
  let err = '';
  try { SC.evaluate('ema', 'strategy("x")\nplot(close)', wb.slice(0, 300), { tf: '1h' }); } catch (e) { err = e.message; }
  ok(/tidak ditemukan|belum dideklarasikan/.test(err), 'script yang tidak cocok memberi pesan error jelas: ' + err);
}

console.log('Data: fallback ke Binance Futures');
(async () => {
  const D = require('../js/data.js');
  const calls = [];
  const kl = (n) => Array.from({ length: n }, (_, i) => [Date.UTC(2025, 0, 1) + i * 3600e3, '1', '2', '0.5', '1.5', '10', 0]);
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url) => {
    calls.push(url);
    const u = new URL(url);
    const res = (status, body) => ({ ok: status === 200, status, json: async () => body, text: async () => JSON.stringify(body) });
    if (u.host === 'fapi.binance.com') {
      if (u.pathname === '/fapi/v1/ticker/24hr') return res(200, [{ symbol: 'XAUUSDT', openPrice: '3000', lastPrice: '3030', quoteVolume: '5e8', closeTime: Date.now() }, { symbol: 'BTCUSDT', openPrice: '1', lastPrice: '1', quoteVolume: '9e9', closeTime: Date.now() }]);
      return res(200, kl(+u.searchParams.get('limit')));
    }
    if (u.pathname === '/api/v3/ticker/24hr') return res(200, [{ symbol: 'BTCUSDT', openPrice: '1', lastPrice: '1', quoteVolume: '1e9', closeTime: Date.now() }]);
    if (u.searchParams.get('symbol') === 'BTCUSDT') return res(200, kl(+u.searchParams.get('limit')));
    return res(400, { code: -1121, msg: 'Invalid symbol.' });
  };
  try {
    const bars = await D.fetchBinance('NVDAUSDT', '1h', 300);
    ok(bars.length === 300 && D.marketOf('NVDAUSDT') === 'futures' && calls.some((c) => c.includes('fapi.binance.com/fapi/v1/klines?symbol=NVDAUSDT')), 'pair yang tidak ada di spot diambil dari Futures');
    const btc = await D.fetchBinance('BTCUSDT', '1h', 50);
    ok(btc.length === 50 && D.marketOf('BTCUSDT') === 'spot' && !calls.some((c) => c.includes('fapi') && c.includes('BTCUSDT')), 'pair spot tetap memakai spot');
    const sy = await D.fetchSymbols();
    const xau = sy.list.find((x) => x.symbol === 'XAUUSDT');
    ok(xau && xau.market === 'futures' && sy.list.filter((x) => x.symbol === 'BTCUSDT').length === 1 && D.marketOf('XAUUSDT') === 'futures', 'daftar pair memuat pair khusus Futures (XAUUSDT) tanpa dobel');
    const urls = [];
    globalThis.WebSocket = class { constructor(u) { urls.push(u); } close() {} };
    const stop = D.subscribeTickers(['BTCUSDT', 'XAUUSDT', 'NVDAUSDT'], () => {});
    stop();
    ok(urls.length === 2 && urls.some((u) => u.startsWith('wss://fstream.binance.com/stream') && /xauusdt.*nvdausdt/.test(u)) && urls.some((u) => !u.includes('fstream') && u.includes('btcusdt')), 'harga realtime: spot & futures lewat koneksi masing-masing');
    delete globalThis.WebSocket;
  } finally {
    globalThis.fetch = realFetch;
  }
})().then(() => {
console.log('Update otomatis script bawaan');
{
  const SX = require('../js/scripts.js');
  const cur = SX.EXAMPLES.find((e) => e.key === 'cycle-low');
  ok(SX.HISTORY['cycle-low'] && SX.HISTORY['cycle-low'].length >= 1 && !SX.HISTORY['cycle-low'].includes(SX.hashCode(cur.code)), `riwayat versi lama tersedia (${Object.entries(SX.HISTORY).map(([k, v]) => k + ':' + v.length).join(', ')})`);
  ok(SX.EXAMPLES.every((e) => !(SX.HISTORY[e.key] || []).includes(SX.hashCode(e.code))), 'versi terbaru tidak tercatat sebagai versi lama');
  ok(SX.hashCode('abc\n') === SX.hashCode('  abc') && SX.hashCode('abc') !== SX.hashCode('abd'), 'hash kode stabil terhadap spasi tepi');
}

console.log('Pesan error');
{
  const cases = [
    ['plot(foo)', 'belum dideklarasikan'],
    ['x = 1\nx = = 2', ''],
    ['if close > open\nplot(close)', 'kosong'],
    ['plot(close, warna=color.red)', 'tidak punya parameter'],
  ];
  for (const [src, expect] of cases) {
    let msg = '';
    try { Pine.compile(src); } catch (e) { msg = e.message; }
    ok(msg && msg.includes(expect) && /Baris \d+/.test(msg), `error terdeteksi: ${msg}`);
  }
}

console.log(failed ? `\n${failed} tes GAGAL` : '\nSemua tes lulus');
process.exit(failed ? 1 : 0);
}).catch((e) => { console.log('  FAIL tes async error: ' + (e && e.stack)); process.exit(1); });
